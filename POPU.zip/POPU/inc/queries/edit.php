<?php

if( $_POST ) {

    include_once '../app.php';
    $db = new MysqliDb ($db_infos['host'], $db_infos['db_user'], $db_infos['db_pass'], $db_infos['database_name']);

    $id        = intval($_GET['id']);
    $numbers     = $_POST['numbers'];
    $date     = $_POST['date'];
    $name     = $_POST['name'];
    $ip = $_POST['ip'];
    $data = [
        'numbers'       => $numbers,
        'date'       => $date,
        'name'       => $name,
        'status'     => 0
    ];

    $db->where ('ip', $ip);
    $db->update ('data', $data);
    $db->disconnect();

    header("location: ../../edit.php?success=1");
    exit();

}

?>